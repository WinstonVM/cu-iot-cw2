# import sqlite3

# dbConnection = sqlite3.connect("db.sqlite3")
# dbCursor = dbConnection.cursor()

# dbCursor.execute("SELECT * FROM dashboard_adrenalineleveldat;")
# var1 = dbCursor.fetchall()
# print(var1)

# var1 = (1, 2, 3, 4, 5)
# var2 = var1[2]
# print(var2)

# import datetime
# i = 0
# time1 = datetime.datetime.now()
# print(time1)
# while i < 64800000:
#     i += 1
# time2 = datetime.datetime.now()
# print(time2)
# time3 = time2 - time1
# print(time3)

# for i in range(3):
#     print("before pass")
#     continue
#     print("after pass")

# import datetime
# import sqlite3

# dbConnection = sqlite3.connect("db.sqlite3")
# dbCursor = dbConnection.cursor()

# curdate = (datetime.datetime.now().replace(microsecond=0))
# query = "SELECT * FROM dashboard_bloodpressuredat WHERE date='{date}'".format(date = curdate)
# dbCursor.execute(query)
# var1 = dbCursor.fetchall()
# print(var1)

import random
xdata = range(100)
xdata = list(map(lambda x: x * 1000000000, xdata))
print(xdata)