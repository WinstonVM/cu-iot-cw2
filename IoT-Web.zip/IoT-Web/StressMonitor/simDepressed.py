'''
THRESHOLDS:
Heart Beat : 101-180 bpm
Blood Pressure : 130-370/80-360
Serotonin : 0-50 ng/ml
Cortisol : 251-400 ng/ml
Adrenaline : 141-300 pg/ml
'''
from os import curdir
import sqlite3
import datetime
import random
from tempfile import TemporaryDirectory

def getMaxKey(tableName):
    dbConnection = sqlite3.connect("db.sqlite3")
    dbCursor = dbConnection.cursor()
    queryScript = ("SELECT MAX({column_name}) FROM {table_name};").format(column_name = "id", table_name = tableName)
    dbCursor.execute(queryScript)
    results = dbCursor.fetchall()
    results = results[0]
    results = results[0]
    if results is None:
        results = 0
    return results

dbConnection = sqlite3.connect("db.sqlite3")
dbCursor = dbConnection.cursor()

startDate = (datetime.datetime.now().replace(microsecond=0)) + datetime.timedelta(hours=4)
endDate = startDate - datetime.timedelta(hours=14)
curDate = startDate
tmpDate = startDate - datetime.timedelta(hours=1)
ctr = 0

startTime = datetime.datetime.now()
print("START: " + str(startTime))

# DECLARE TABLE NAMES
hbTableName = "dashboard_heartbeatdat"
bpTableName = "dashboard_bloodpressuredat"
clTableName = "dashboard_cortisolleveldat"
alTableName = "dashboard_adrenalineleveldat"
slTableName = "dashboard_serotoninleveldat"

# EXTRACT MAX KEY VAL
hbKey = getMaxKey(hbTableName) + 1
bpKey = getMaxKey(bpTableName) + 1
clKey = getMaxKey(clTableName) + 1
alKey = getMaxKey(alTableName) + 1
slKey = getMaxKey(slTableName) + 1

while curDate >= endDate:
    curDate -= datetime.timedelta(seconds=1)

    if curDate == tmpDate:
        print("Passed Hour " + str(ctr + 1))
        ctr += 1
        tmpDate -= datetime.timedelta(hours=1)

    # MAKE THE TELEMETRY DATA
    hbTelemetry = random.randint(101, 180)
    diastolTelemetry = random.randint(81, 360)
    systolTelemetry = random.randint(131, 370)
    clTelemetry = random.randint(251, 400)
    alTelemetry = random.randint(141, 300)
    slTelemetry = random.randint(0, 50)

    # CREATE NEW INSERT SCRIPTS
    hbInsertScript = "INSERT INTO {tablename}(id, hbDat, username_id, date) VALUES({uniqid}, {dataval}, '{userid}', '{date}');".format(tablename = hbTableName, dataval = hbTelemetry, uniqid = hbKey, userid = "johndoe", date = curDate)
    bpInsertScript = "INSERT INTO {tablename}(id, username_id, date, bPDiastolic, bpSystolic) VALUES({uniqid}, '{userid}', '{date}', {dystolicDat}, {systolicDat});".format(tablename = bpTableName, uniqid = bpKey, userid = "johndoe", date = curDate, dystolicDat = diastolTelemetry, systolicDat = systolTelemetry)
    clInsertScript = "INSERT INTO {tablename}(id, clDat, username_id, date) VALUES({uniqid}, {dataval}, '{userid}', '{date}');".format(tablename = clTableName, uniqid = clKey, dataval = clTelemetry, userid = "johndoe", date = curDate)
    alInsertScript = "INSERT INTO {tablename}(id, alDat, username_id, date) VALUES({uniqid}, {dataval}, '{userid}', '{date}');".format(tablename = alTableName, uniqid = alKey, dataval = alTelemetry, userid = "johndoe", date = curDate)
    slInsertScript = "INSERT INTO {tablename}(id, slDat, username_id, date) VALUES({uniqid}, {dataval}, '{userid}', '{date}');".format(tablename = slTableName, uniqid = slKey, dataval = slTelemetry, userid = "johndoe", date = curDate)

    # INSCREMENT KEY VALUE
    hbKey += 1
    bpKey += 1
    clKey += 1
    alKey += 1
    slKey += 1

    # EXECUTE SCRIPTS
    dbCursor.execute(hbInsertScript)
    dbCursor.execute(bpInsertScript)
    dbCursor.execute(clInsertScript)
    dbCursor.execute(alInsertScript)
    dbCursor.execute(slInsertScript)

    # COMMIT TO DATABASE
    dbConnection.commit()

endTime = datetime.datetime.now()
print("END: " + str(endTime))
print("Time Elapsed: " + str(endTime - startTime))