from dataFiltAlgo import dataFilter

'''
THRESHOLDS:
Heart Beat : 101-180 bpm is considered high
Blood Pressure : 130-370/80-360 is considered high
Serotonin : 0-50 ng/ml is considered less happy
Cortisol : 251-400 ng/ml is considered high
Adrenaline : 141-300 pg/ml is considered high
'''

'''
STRESS STAT INFO:
Non-Existent: 0%
Mild: 1-25%
Moderate: 26-50%
High: 51-75%
Critical: 76-100%
'''

def getRate(sLevel, sMax):
    results = (sLevel / sMax) * 100
    return results

def increment(curStress):
    curStress += 5
    return curStress

def decrement(curStress, decVal):
    if curStress - decVal < 0:
        curStress = 0
    else:
        curStress -= decVal
    return curStress

def calcStress():
    # DECLARE VARIABLES
    stressWeightage = 0
    maxStress = 0
    hasStressHist = False
    isDepressed = False
    stressStat = ""
    ctr = 0
    bpLimit = 100
    bpDystolic = 80 # dystolic is the one coming last
    bpSystolic = 130 # systolic is the one coming first
    clLimit = 250
    alLimit = 140
    slLimit = 51 # anything lower than this value is alarming
    timeList = []

    allDat = dataFilter()

    # SEPARATE DATA
    heartBeatData = allDat[0]
    bloodPressureData = allDat[1]
    cortisolData = allDat[2]
    adrenalineData = allDat[3]
    serotoninData = allDat[4]

    # GET ALL TIMESTAMPS
    for i in heartBeatData:
        timeRec = i[1]
        timeList.append(timeRec)
    maxStress = len(timeList) * 5

    while ctr < (maxStress / 5):
        hbDat = heartBeatData[ctr]
        bpDat = bloodPressureData[ctr]
        clDat = cortisolData[ctr]
        alDat = adrenalineData[ctr]
        slDat = serotoninData[ctr]

        if getRate(stressWeightage, maxStress) > 75:
            stressStat = "Critical"
            hasStressHist = True
        elif getRate(stressWeightage, maxStress) > 50:
            stressStat = "High"
            hasStressHist = True
        elif getRate(stressWeightage, maxStress) > 25:
            stressStat = "Moderate"
            hasStressHist = True
        elif getRate(stressWeightage, maxStress) > 0:
            stressStat = "Mild"
        else:
            stressStat = "Not Stressed"
        
        # CALCULATE STRESS WEIGHTAGE
        if hbDat[3] > bpLimit and (bpDat[3] > bpDystolic or bpDat[4] > bpSystolic) and clDat[3] > clLimit and alDat[3] > alLimit:
            stressWeightage = increment(stressWeightage)
        elif hbDat[3] <= bpLimit and bpDat[3] <= bpDystolic and bpDat[4] <= bpSystolic and clDat[3] <= clLimit and alDat[3] <= alLimit:
            stressWeightage = decrement(stressWeightage, 5)
        
        # DETERMINE IF DEPRESSED
        if hasStressHist and slDat[3] < slLimit:
            isDepressed = True
        else:
            isDepressed = False

        ctr += 1
    
    if isDepressed:
        stressStat = "Depressed"
    
    results = [stressStat, heartBeatData, bloodPressureData, cortisolData, adrenalineData, serotoninData]
    return results