import sqlite3

dbConn = sqlite3.connect("db.sqlite3")
dbCursor = dbConn.cursor()

script1 = "DELETE FROM dashboard_heartbeatdat;"
script2 = "DELETE FROM dashboard_bloodpressuredat;"
script3 = "DELETE FROM dashboard_adrenalineleveldat;"
script4 = "DELETE FROM dashboard_cortisolleveldat;"
script5 = "DELETE FROM dashboard_serotoninleveldat;"

dbCursor.execute(script1)
dbCursor.execute(script2)
dbCursor.execute(script3)
dbCursor.execute(script4)
dbCursor.execute(script5)

dbConn.commit()