def dataFilter():
    import datetime
    import sqlite3

    # ESTABLISH CONNECTION WITH DATABASE AND CREATE DATABASE CURSOR
    dbConnection = sqlite3.connect("db.sqlite3")
    dbCursor = dbConnection.cursor()

    recTimes = []
    hbList = []
    bpList = []
    clList = []
    alList = []
    slList = []
    loopsCount = 40
    curDT = (datetime.datetime.now().replace(microsecond=0)) - datetime.timedelta(seconds=1)
    hBTableName = "dashboard_heartbeatdat"
    bPTableName = "dashboard_bloodpressuredat"
    cLTableName = "dashboard_cortisolleveldat"
    aLTableName = "dashboard_adrenalineleveldat"
    sLTableName = "dashboard_serotoninleveldat"

    # MAKE ALL TIMESTAMPS
    for i in range(loopsCount):
        recTimes.append(curDT)
        curDT = (curDT - datetime.timedelta(minutes=15)).replace(microsecond=0)
        
    
    for i in recTimes:
        # MAKE QUERY SCRIPTS
        hBScript = ("SELECT * FROM {table_name} WHERE date='{date_value}'").format(table_name = hBTableName, date_value = i)
        bPScript = ("SELECT * FROM {table_name} WHERE date='{date_value}'").format(table_name = bPTableName, date_value = i)
        cLScript = ("SELECT * FROM {table_name} WHERE date='{date_value}'").format(table_name = cLTableName, date_value = i)
        aLScript = ("SELECT * FROM {table_name} WHERE date='{date_value}'").format(table_name = aLTableName, date_value = i)
        sLScript = ("SELECT * FROM {table_name} WHERE date='{date_value}'").format(table_name = sLTableName, date_value = i)

        # EXECUTE QUERY SCRIPTS
        dbCursor.execute(hBScript)
        hbDat = dbCursor.fetchall()
        if len(hbDat) == 0:
            continue

        dbCursor.execute(bPScript)
        bpDat = dbCursor.fetchall()
        if len(bpDat) == 0:
            continue

        dbCursor.execute(cLScript)
        clDat = dbCursor.fetchall()
        if len(clDat) == 0:
            continue
        
        dbCursor.execute(aLScript)
        alDat = dbCursor.fetchall()
        if len(alDat) == 0:
            continue
        
        dbCursor.execute(sLScript)
        slDat = dbCursor.fetchall()        
        if len(slDat) == 0:
            continue

        # REMOVE DATA FROM LIST AND TUPLES
        hbDat = list(hbDat[0])
        bpDat = list(bpDat[0])
        clDat = list(clDat[0])
        alDat = list(alDat[0])
        slDat = list(slDat[0])

        # APPEND ITEMS TO LIST
        hbList.append(hbDat)
        bpList.append(bpDat)
        clList.append(clDat)
        alList.append(alDat)
        slList.append(slDat)
    
    filteredDat = [hbList, bpList, clList, alList, slList]
    return filteredDat