from django.db import models
import datetime

class userInfo(models.Model):
    username = models.CharField( primary_key=True, max_length=64, default="NULL")
    firstName = models.CharField(max_length=64)
    lastName = models.CharField(max_length=64)
    dateOfBirth = models.DateField()
    gender = models.CharField(max_length=8)

class HeartBeatDat(models.Model):
    username = models.ForeignKey(userInfo, on_delete=models.CASCADE, default="NULL")
    hBDat = models.IntegerField(default=0)
    date = models.DateTimeField(datetime.datetime.now())

class CortisolLevelDat(models.Model):
    username = models.ForeignKey(userInfo, on_delete=models.CASCADE, default="NULL")
    cLDat = models.IntegerField(default=0)
    date = models.DateTimeField(datetime.datetime.now())

class AdrenalineLevelDat(models.Model):
    username = models.ForeignKey(userInfo, on_delete=models.CASCADE, default="NULL")
    aLDat = models.IntegerField(default=0)
    date = models.DateTimeField(datetime.datetime.now())

class BloodPressureDat(models.Model):
    username = models.ForeignKey(userInfo, on_delete=models.CASCADE, default="NULL")
    bpSystolic = models.IntegerField(default=0)
    bPDiastolic = models.IntegerField(default=0)
    date = models.DateTimeField(datetime.datetime.now())

class SerotoninLevelDat(models.Model):
    username = models.ForeignKey(userInfo, on_delete=models.CASCADE, default="NULL")
    sLDat = models.IntegerField(default=0)
    date = models.DateTimeField(datetime.datetime.now())