from django.contrib import admin
from .models import userInfo, HeartBeatDat, CortisolLevelDat, AdrenalineLevelDat, BloodPressureDat, SerotoninLevelDat

admin.site.register(userInfo)
admin.site.register(HeartBeatDat)
admin.site.register(CortisolLevelDat)
admin.site.register(AdrenalineLevelDat)
admin.site.register(BloodPressureDat)
admin.site.register(SerotoninLevelDat)