import xdrlib
from django.shortcuts import render
import random
import datetime
import time
from sndAlgo import *

def dashboard(request):
    """
    lineChart page
    """

    # DECLARE VARIABLES
    hbYDat = []
    bpYDatSys = []
    bpYDatDias = []
    clYDat = []
    alYDat = []
    slYDat = []
    xDat = []

    # EXTRACT DATA
    processedData = calcStress()
    stressStat = processedData[0]
    heartBeatData = processedData[1]
    bloodPressureData = processedData[2]
    cortisolData = processedData[3]
    adrenalineData = processedData[4]
    serotoninData = processedData[5]

    for i in heartBeatData:
        hbData = int(i[3])
        dates = i[1]
        hbYDat.append(hbData)
        xDat.append(dates)
    
    for i in bloodPressureData:
        diastolicData = int(i[3])
        systolicData = int(i[4])
        bpYDatDias.append(diastolicData)
        bpYDatSys.append(systolicData)
    
    for i in cortisolData:
        clDat = int(i[3])
        clYDat.append(clDat)
    
    for i in adrenalineData:
        alDat = int(i[3])
        alYDat.append(alDat)
    
    for i in serotoninData:
        slDat = int(i[3])
        slYDat.append(slDat)

    xDat = len(xDat)
    xDat = range(xDat)
    hbChartData = {
        "x": xDat,
        "name": "Heart Rate", "y": hbYDat
    }

    bpChartData = {
        "x": xDat,
        "name1": "Systolic Data", "y1": bpYDatSys,
        "name2": "Diastolic Data", "y2": bpYDatDias
    }
    
    clChartData = {
        "x": xDat,
        "name": "Cortisol Levels", "y": clYDat
    }
    
    alChartData = {
        "x": xDat,
        "name": "Adrenaline Levels", "y": alYDat
    }
    
    slChartData = {
        "x": xDat,
        "name": "Serotonin Levels", "y": slYDat
    }

    charttype = "lineChart"
    data = {
        'charttype': charttype,
        'chartdataHB': hbChartData,
        'chartdataBP': bpChartData,
        'chartdataCL': clChartData,
        'chartdataAL': alChartData,
        'chartdataSL': slChartData,
        'stressStat': stressStat
    }

    return render(request, 'dashboard.html', data)