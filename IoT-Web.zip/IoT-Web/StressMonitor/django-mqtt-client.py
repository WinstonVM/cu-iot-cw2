from datetime import datetime
import time
import paho.mqtt.client as paho
import datetime
import sqlite3
import json

def getMaxKey(tableName):
    dbConnection = sqlite3.connect("db.sqlite3")
    dbCursor = dbConnection.cursor()
    queryScript = ("SELECT MAX({column_name}) FROM {table_name};").format(column_name = "id", table_name = tableName)
    dbCursor.execute(queryScript)
    results = dbCursor.fetchall()
    results = results[0]
    results = results[0]
    if results is None:
        results = 0
    return results

# STORE FUNCTIONS
def storeHeartRate(dataValue, username):
    # DEFINE VARIABLES
    tableName = "dashboard_heartbeatdat"
    curPK = (getMaxKey(tableName)) + 1
    curDate = datetime.datetime.now().replace(microsecond=0)

    # INSERT TO DATABASE
    insertScript = ("INSERT INTO {tablename}(id, hBDat, username_id, date) VALUES({uniqid}, {dataval}, '{userid}', '{date}');").format(tablename = tableName, uniqid = curPK, dataval = dataValue, userid = username, date = curDate)
    dbConnection = sqlite3.connect("db.sqlite3")
    dbCursor = dbConnection.cursor()
    dbCursor.execute(insertScript)
    dbConnection.commit()

def storeBloodPressure(dataValue, username):
    # DEFINE VARIABLES
    dataValue = json.loads(dataValue)
    tableName = "dashboard_bloodpressuredat"
    curPK = (getMaxKey(tableName)) + 1
    curDate = datetime.datetime.now().replace(microsecond=0)
    systolicDat = dataValue["systolic"]
    diastolicDat = dataValue["dystolic"]

    # INSERT TO DATABASE
    insertScript = ("INSERT INTO {tablename}(id, username_id, date, bPDiastolic, bpSystolic) VALUES({uniqid}, '{userid}', '{date}', {dystolicDat}, {systolicDat});").format(tablename = tableName, uniqid = curPK, userid = username, date = curDate, dystolicDat = diastolicDat, systolicDat = systolicDat)
    dbConnection = sqlite3.connect("db.sqlite3")
    dbCursor = dbConnection.cursor()
    dbCursor.execute(insertScript)
    dbConnection.commit()

def storeCortisol(dataValue, username):
    # DEFINE VARIABLES
    tableName = "dashboard_cortisolleveldat"
    curPK = (getMaxKey(tableName)) + 1
    curDate = datetime.datetime.now().replace(microsecond=0)

    # INSERT TO DATABASE
    insertScript = ("INSERT INTO {tablename}(id, cLDat, username_id, date) VALUES({uniqid}, {dataval}, '{userid}', '{date}');").format(tablename = tableName, uniqid = curPK, dataval = dataValue, userid = username, date = curDate)
    dbConnection = sqlite3.connect("db.sqlite3")
    dbCursor = dbConnection.cursor()
    dbCursor.execute(insertScript)
    dbConnection.commit()

def storeAdrenaline(dataValue, username):
    # DEFINE VARIABLES
    tableName = "dashboard_adrenalineleveldat"
    curPK = (getMaxKey(tableName)) + 1
    curDate = datetime.datetime.now().replace(microsecond=0)

    # INSERT TO DATABASE
    insertScript = ("INSERT INTO {tablename}(id, aLDat, username_id, date) VALUES({uniqid}, {dataval}, '{userid}', '{date}');").format(tablename = tableName, uniqid = curPK, dataval = dataValue, userid = username, date = curDate)
    dbConnection = sqlite3.connect("db.sqlite3")
    dbCursor = dbConnection.cursor()
    dbCursor.execute(insertScript)
    dbConnection.commit()

def storeSerotonin(dataValue, username):
    # DEFINE VARIABLES
    tableName = "dashboard_serotoninleveldat"
    curPK = (getMaxKey(tableName)) + 1
    curDate = datetime.datetime.now().replace(microsecond=0)

    # INSERT TO DATABASE
    insertScript = ("INSERT INTO {tablename}(id, sLDat, username_id, date) VALUES({uniqid}, {dataval}, '{userid}', '{date}');").format(tablename = tableName, uniqid = curPK, dataval = dataValue, userid = username, date = curDate)
    dbConnection = sqlite3.connect("db.sqlite3")
    dbCursor = dbConnection.cursor()
    dbCursor.execute(insertScript)
    dbConnection.commit()

# NEW ON_MESSAGE FUNCTIONS
def on_messageHR(client, userdata, message):
    msgDecoded = str(message.payload.decode("utf-8"))
    username = "johndoe"

    storeHeartRate(msgDecoded, username)

def on_messageBP(client, userdata, message):
    msgDecoded = str(message.payload.decode("utf-8"))
    username = "johndoe"

    storeBloodPressure(msgDecoded, username)

def on_messageC(client, userdata, message):
    msgDecoded = str(message.payload.decode("utf-8"))
    username = "johndoe"

    storeCortisol(msgDecoded, username)

def on_messageA(client, userdata, message):
    msgDecoded = str(message.payload.decode("utf-8"))
    username = "johndoe"

    storeAdrenaline(msgDecoded, username)

def on_messageS(client, userdata, message):
    msgDecoded = str(message.payload.decode("utf-8"))
    username = "johndoe"

    storeSerotonin(msgDecoded, username)

def main():
    broker="localhost"

    # CREATE NECESSARY CLIENTS
    heartRateClient = paho.Client("client-000") # HEART RATE CLIENT
    bloodPressureClient = paho.Client("client-001") # BLOOD PRESSURE CLIENT
    cortsiolClient = paho.Client("client-002") # CORTISOL CLIENT
    adrenalineClient = paho.Client("client-003") # ADRENALINE CLIENT
    serotoninClient = paho.Client("client-004") # SEROTONIN CLIENT

    # UPDATE CLIENT METHODS
    heartRateClient.on_message = on_messageHR
    bloodPressureClient.on_message = on_messageBP
    cortsiolClient.on_message = on_messageC
    adrenalineClient.on_message = on_messageA
    serotoninClient.on_message = on_messageS

    # CONNECT TO BROKER
    print("Connecting to Broker:", broker)
    heartRateClient.connect(broker)
    bloodPressureClient.connect(broker)
    cortsiolClient.connect(broker)
    adrenalineClient.connect(broker)
    serotoninClient.connect(broker)

    # START RECEIVED MESSAGE PROCESSING LOOP
    heartRateClient.loop_start()
    bloodPressureClient.loop_start()
    cortsiolClient.loop_start()
    adrenalineClient.loop_start()
    serotoninClient.loop_start()

    # SUBSCRIBE TO TOPICS
    print("Subscribing")
    heartRateClient.subscribe("heartRate")
    bloodPressureClient.subscribe("bloodPressure")
    cortsiolClient.subscribe("cortisolLevel")
    adrenalineClient.subscribe("adrenalineLevel")
    serotoninClient.subscribe("serotoninLevel")

    # PREVENT PROGRAM FROM ENDING
    while True:
        time.sleep(1)
main()